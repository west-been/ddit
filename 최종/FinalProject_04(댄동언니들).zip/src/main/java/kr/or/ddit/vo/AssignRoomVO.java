package kr.or.ddit.vo;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(of = "assignRoomId")
@ToString
public class AssignRoomVO {
	private String assignRoomId;
	private LectRoomVO lectRoomVO;
	private String lectTimeId;
}
