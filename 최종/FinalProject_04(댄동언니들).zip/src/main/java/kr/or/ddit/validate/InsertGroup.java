package kr.or.ddit.validate;

import javax.validation.groups.Default;

/**
 * Marker Interface : 검증 자료를 분리하는 용도로만 사용
 */
public interface InsertGroup extends Default {

}
