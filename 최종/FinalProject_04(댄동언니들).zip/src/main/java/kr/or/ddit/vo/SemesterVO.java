package kr.or.ddit.vo;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(of="semeId")
public class SemesterVO implements Serializable{

	private String semeId;
	private String semeYear;
	private String seme;
}
