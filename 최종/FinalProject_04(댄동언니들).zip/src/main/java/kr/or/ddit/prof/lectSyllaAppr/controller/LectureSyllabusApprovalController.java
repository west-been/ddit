package kr.or.ddit.prof.lectSyllaAppr.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *  강의계획서승인 컨트롤러
 * @author 민경진
 *
 */
@Controller
public class LectureSyllabusApprovalController {

	@RequestMapping("/prof/lectSyllaAppr")
	public String lectSyllaAppr() {
		return "prof/lectSyllaAppr/lectSyllaAppr";
	}
}
