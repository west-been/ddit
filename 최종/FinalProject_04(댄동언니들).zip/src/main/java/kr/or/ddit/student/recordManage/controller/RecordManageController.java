package kr.or.ddit.student.recordManage.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 학적관리 컨트롤러
 * @author 민경진
 *
 */
@Controller
public class RecordManageController {

	@RequestMapping("/student/recordManage")
	public String recordManage() {
		return "student/recordManage/recordManage";
	}
}
