package kr.or.ddit.vo;

import java.util.List;

import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(of="laboId")
@ToString
public class LaboVO extends UsrVO {
	
	private int rnum;
	private String laboId;
	private String buildId;
	private String laboTel;
	private String buildNum;
}
