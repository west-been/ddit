package kr.or.ddit.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

@Data
@EqualsAndHashCode(of="scoreCritId")
@ToString
public class ScoreCritVO {
	private String scoreCritId;
	private String syllaId;
	private String scoreCritNm;
	private String scoreCritRatio;
}
