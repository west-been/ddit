package kr.or.ddit.vo;

import java.util.List;

import lombok.Data;

@Data
public class SyllaApprVO {
	private String syllaApprId;
	private List<SyllabusVO> syllabusVO;
	private ProfessorVO professorVO;
	private String aprvDate;
	private String rejectReason;
	private String aprvState;
}
