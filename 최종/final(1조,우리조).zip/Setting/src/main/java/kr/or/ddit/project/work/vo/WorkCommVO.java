package kr.or.ddit.project.work.vo;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(of="workCommNo")
public class WorkCommVO {
	
	private Integer workCommNo; // 작업 댓글 번호
	private Integer workNo; // 작업 번호
	private String workCommCont; // 작업 댓글 내용
	private String workCommDate; // 작없 댓글 작성 날짜
	private String memEmail; // 작성자
	private Integer workCommPntNo; // 상위 댓글
	private String memAttPath;
	
}

