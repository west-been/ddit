package kr.or.ddit.project.news.vo;

import lombok.Data;

@Data
public class NewsCommVO {
	
    //댓글기능
	private Integer newsCommNo; //댓글번호
	private Integer newsNo; //뉴스글번호(부모글)
	private String memEmail; //작성자이메일
	private String proCode; //프로젝트코드 
	private Integer newsCommPnt; //댓글 부모 번호(대댓글 시 사용 가능)
	private String newsCommCont; //댓글 내용
	private String newsCommDate; //댓글 작성 일자
}
