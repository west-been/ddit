package kr.or.ddit.sample.dao;

public interface SampleDAO {
	public String selectRawData(String primaryKey);
}
