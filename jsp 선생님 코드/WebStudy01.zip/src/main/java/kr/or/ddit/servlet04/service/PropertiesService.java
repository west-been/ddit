package kr.or.ddit.servlet04.service;

import java.util.Properties;

public interface PropertiesService {
	public Properties retrieveData();
}
