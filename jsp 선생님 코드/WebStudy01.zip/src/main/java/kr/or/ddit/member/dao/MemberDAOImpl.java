package kr.or.ddit.member.dao;

import java.sql.Statement;
import java.util.List;
import java.util.Map;

import kr.or.ddit.vo.MemberVO;

public class MemberDAOImpl extends AbstractJDBCDAO implements MemberDAO {
	private Map<String, Statement> statementMap;
	

	@Override
	public int insertMember(MemberVO member) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<MemberVO> selectMemberList() {
		StringBuffer sql = new StringBuffer();
//		1.
		sql.append(" SELECT MEM_ID, MEM_NAME, MEM_MAIL, MEM_HP     ");
		sql.append(" 	, MEM_ADD1, MEM_MILEAGE                    ");
		sql.append(" FROM MEMBER                                   ");
		
		return selectList(sql.toString(), MemberVO.class);
	}

	@Override
	public MemberVO selectMember(String memId) {
		StringBuffer sql = new StringBuffer();
		sql.append(" SELECT                                                         ");
		sql.append("     mem_id,    mem_pass,    mem_name,                          ");
		sql.append("     mem_regno1,    mem_regno2,                                 ");
		sql.append("     to_char(mem_bir, 'YYYY-MM-DD') MEM_BIR,                    ");
		sql.append("     mem_zip,    mem_add1,    mem_add2,                         ");
		sql.append("     mem_hometel,    mem_comtel,    mem_hp,                     ");
		sql.append("     mem_mail,    mem_job,    mem_like,                         ");
		sql.append("     mem_memorial,                                              ");
		sql.append("     TO_CHAR(mem_memorialday, 'YYYY-MM-DD') mem_memorialday,    ");
		sql.append("     mem_mileage,                                               ");
		sql.append("     mem_delete                                                 ");
		sql.append(" FROM    member                                                 ");
		sql.append(" WHERE MEM_ID = ?                                               ");
		
		return selectOne(sql.toString(), MemberVO.class, memId);
	}

	@Override
	public int updateMember(MemberVO member) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMember(String memId) {
		// TODO Auto-generated method stub
		return 0;
	}

}











