package kr.or.ddit;

import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@RootContextConfiguration
public abstract class AbstractTestCase {

}
